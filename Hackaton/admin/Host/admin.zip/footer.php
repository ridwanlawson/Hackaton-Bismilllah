      <footer class="main-footer">
        <div class="footer-left">
          Copyright &copy; 2018 <div class="bullet"></div> Design By <a href="https://nauval.in/">Muhamad Nauval Azhar</a>
        </div>
        <div class="footer-right">
          
        </div>
      </footer>
    </div>
  </div>

  <!-- General JS Scripts -->
  <script src="dist/assets/modules/jquery.min.js"></script>
  <script src="dist/assets/modules/popper.js"></script>
  <script src="dist/assets/modules/tooltip.js"></script>
  <script src="dist/assets/modules/bootstrap/js/bootstrap.min.js"></script>
  <script src="dist/assets/modules/nicescroll/jquery.nicescroll.min.js"></script>
  <script src="dist/assets/modules/moment.min.js"></script>
  <script src="dist/assets/js/stisla.js"></script>
  
  <!-- JS Libraies -->
  <script src="dist/assets/modules/prism/prism.js"></script>
  <script src="dist/assets/modules/summernote/summernote-bs4.js"></script>
  <script src="dist/assets/modules/codemirror/lib/codemirror.js"></script>
  <script src="dist/assets/modules/codemirror/mode/javascript/javascript.js"></script>
  <script src="dist/assets/modules/jquery-selectric/jquery.selectric.min.js"></script>
  <script src="dist/assets/modules/datatables/datatables.min.js"></script>
  <script src="dist/assets/modules/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js"></script>
  <script src="dist/assets/modules/datatables/Select-1.2.4/js/dataTables.select.min.js"></script>
  <script src="dist/assets/modules/jquery-ui/jquery-ui.min.js"></script>
  
  <!-- Page Specific JS File -->
  <script src="dist/assets/js/page/bootstrap-modal.js"></script>
  <script src="dist/assets/js/page/modules-datatables.js"></script>
  <script src="dist/assets/modules/jquery-selectric/jquery.selectric.min.js"></script>


  <!-- Template JS File -->
  <script src="dist/assets/js/scripts.js"></script>
  <script src="dist/assets/js/custom.js"></script>
  <!-- Start of LiveChat (www.livechatinc.com) code -->
<script type="text/javascript">
  window.__lc = window.__lc || {};
  window.__lc.license = 11229782;
  (function() {
    var lc = document.createElement('script'); lc.type = 'text/javascript'; lc.async = true;
    lc.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'cdn.livechatinc.com/tracking.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(lc, s);
  })();
</script>
<noscript>
<a href="https://www.livechatinc.com/chat-with/11229782/" rel="nofollow">Chat with us</a>,
powered by <a href="https://www.livechatinc.com/?welcome" rel="noopener nofollow" target="_blank">LiveChat</a>
</noscript>
<!-- End of LiveChat code -->
</body>
</html>