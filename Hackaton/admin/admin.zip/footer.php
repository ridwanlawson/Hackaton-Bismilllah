      <footer class="main-footer">
        <div class="footer-left">
          Copyright &copy; 2018 <div class="bullet"></div> Design By <a href="https://nauval.in/">Muhamad Nauval Azhar</a>
        </div>
        <div class="footer-right">
          
        </div>
      </footer>
    </div>
  </div>

  <!-- General JS Scripts -->
  <script src="dist/assets/modules/jquery.min.js"></script>
  <script src="dist/assets/modules/popper.js"></script>
  <script src="dist/assets/modules/tooltip.js"></script>
  <script src="dist/assets/modules/bootstrap/js/bootstrap.min.js"></script>
  <script src="dist/assets/modules/nicescroll/jquery.nicescroll.min.js"></script>
  <script src="dist/assets/modules/moment.min.js"></script>
  <script src="dist/assets/js/stisla.js"></script>
  
  <!-- JS Libraies -->
  <script src="dist/assets/modules/prism/prism.js"></script>
  <script src="dist/assets/modules/summernote/summernote-bs4.js"></script>
  <script src="dist/assets/modules/codemirror/lib/codemirror.js"></script>
  <script src="dist/assets/modules/codemirror/mode/javascript/javascript.js"></script>
  <script src="dist/assets/modules/jquery-selectric/jquery.selectric.min.js"></script>
  <script src="dist/assets/modules/datatables/datatables.min.js"></script>
  <script src="dist/assets/modules/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js"></script>
  <script src="dist/assets/modules/datatables/Select-1.2.4/js/dataTables.select.min.js"></script>
  <script src="dist/assets/modules/jquery-ui/jquery-ui.min.js"></script>
  
  <!-- Page Specific JS File -->
  <script src="dist/assets/js/page/bootstrap-modal.js"></script>
  <script src="dist/assets/js/page/modules-datatables.js"></script>
  <script src="dist/assets/modules/jquery-selectric/jquery.selectric.min.js"></script>


  <!-- Template JS File -->
  <script src="dist/assets/js/scripts.js"></script>
  <script src="dist/assets/js/custom.js"></script>
</body>
</html>